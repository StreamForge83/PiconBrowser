from hashlib import md5
from os.path import exists, islink, join
from os import remove, symlink

from twisted.internet import reactor
from twisted.internet.defer import Deferred, inlineCallbacks
from twisted.internet.protocol import Protocol
from twisted.web.client import Agent, BrowserLikeRedirectAgent, ResponseDone, readBody
from twisted.web.http_headers import Headers

from Components.config import config, ConfigSelection, ConfigSubsection, ConfigYesNo
from Plugins.Plugin import PluginDescriptor
from Screens.Setup import Setup
from Tools.Directories import resolveFilename, SCOPE_CURRENT_PLUGIN

from . import _, PluginLanguageDomain
from .BouquetParser import BouquetParser, getChannelKey, getCleanFileName

PLUGIN_NAME = "PiconBrowser"
BOUQUET_PATH = "/etc/enigma2"
MAX_SETS = 4
SCHEDULER_TIMER_KEY = "PiconBrowserSync"

# GitHub Pages base URL of every available picon repo. More may be added later.
REPOS = {
	"100-light-transparent": "https://piconbrowser.github.io/100-light-transparent",
	"100-dark-transparent": "https://piconbrowser.github.io/100-dark-transparent",
	"220-light-transparent": "https://piconbrowser.github.io/220-light-transparent",
	"220-dark-transparent": "https://piconbrowser.github.io/220-dark-transparent",
	"400-light-transparent": "https://piconbrowser.github.io/400-light-transparent",
	"400-dark-transparent": "https://piconbrowser.github.io/400-dark-transparent",
}

config.plugins.PiconBrowser = ConfigSubsection()
config.plugins.PiconBrowser.enabled = ConfigYesNo(default=False)
config.plugins.PiconBrowser.excludeIptv = ConfigYesNo(default=True)
config.plugins.PiconBrowser.excludeRadio = ConfigYesNo(default=False)
for index in range(MAX_SETS):
	section = ConfigSubsection()
	section.repo = ConfigSelection(default="220-light-transparent", choices=[(name, name) for name in REPOS])
	setattr(config.plugins.PiconBrowser, f"sets{index}", section)


def getActivePiconPaths():
	# Picon target directories are owned by the core Picon settings (config.picon), not by
	# this plugin - it only picks a repo per path that's actually in use for rendering.
	paths = [config.picon.set0.path.value]
	if config.picon.mode.value == 1:
		for index in range(1, MAX_SETS):
			path = getattr(config.picon, f"set{index}").path.value
			if path:
				paths.append(path)
	return paths


class PiconBrowserSetup(Setup):
	def __init__(self, session):
		Setup.__init__(self, session, "PiconBrowser", plugin="Extensions/PiconBrowser", PluginLanguageDomain=PluginLanguageDomain)

	def keySave(self):
		config.plugins.PiconBrowser.save()
		Setup.keySave(self)


class _PiconFileSaver(Protocol):
	"""Writes a response body straight to a local file as it arrives."""

	def __init__(self, finished, path):
		self.finished = finished
		self.file = open(path, "wb")

	def dataReceived(self, data):
		self.file.write(data)

	def connectionLost(self, reason):
		self.file.close()
		if reason.check(ResponseDone):
			self.finished.callback(None)
		else:
			self.finished.errback(reason)


class PiconSync:
	"""Syncs the PNGs published on a PiconBrowser GitHub Pages repo into a local directory."""

	def __init__(self, repoUrl, localPath, serviceList):
		self.repoUrl = repoUrl.rstrip("/")
		self.localPath = localPath
		self.serviceList = serviceList
		self.agent = BrowserLikeRedirectAgent(Agent(reactor))

	@inlineCallbacks
	def run(self):
		remoteMd5 = yield self._fetchMd5(f"{self.repoUrl}/info/files.md5")
		print(f"[{PLUGIN_NAME}] {len(remoteMd5)} entrie(s) in {self.repoUrl}/info/files.md5")
		remoteMap = yield self._fetchMap(f"{self.repoUrl}/info/files.map")
		print(f"[{PLUGIN_NAME}] {len(remoteMap)} entrie(s) in {self.repoUrl}/info/files.map")

		neededReal, neededAliases, missingChannels = self._determineNeededPicons(remoteMd5, remoteMap)
		print(f"[{PLUGIN_NAME}] {len(neededReal)} real picon(s), {len(neededAliases)} alias(es), {len(missingChannels)} missing")

		existing = {name for name in neededReal if exists(join(self.localPath, name))}
		missing = neededReal - existing
		print(f"[{PLUGIN_NAME}] downloading {len(missing)} missing picon(s)")
		for name in missing:
			yield self._downloadPicon(name)

		localMd5 = self._localMd5(existing)
		changed = {name for name in existing if localMd5.get(name) != remoteMd5.get(name)}
		for name in changed:
			yield self._downloadPicon(name)

		for target, source in neededAliases.items():
			yield self._createSymlink(source, target)

		self._writeMissingReport(missingChannels)

		return len(missing), len(changed), len(missingChannels)

	def _determineNeededPicons(self, remoteMd5, remoteMap):
		# The local picon is always saved under the service reference (sref) name, since
		# that's what enigma2 looks up. The actual file on git is named after the channel
		# name, mapped via files.map - or, if not listed there, named after the channel
		# name directly. files.md5 lists every real png that is actually available.
		neededAliases = {}
		missingChannels = []
		for service in self.serviceList:
			sref = getChannelKey(service)
			if not sref:
				continue
			serviceName = service.getServiceName().replace("\x80", "").replace("\x86", "").replace("\x87", "")
			if not serviceName.strip():
				continue
			cleanName = getCleanFileName(service.getServiceName())
			channelName = f"{cleanName}.png"
			realName = f"{remoteMap.get(cleanName, cleanName)}.png"
			if realName in remoteMd5:
				neededAliases[f"{sref}.png"] = realName
			else:
				missingChannels.append((serviceName, channelName, sref))

		neededReal = set(neededAliases.values())
		return neededReal, neededAliases, missingChannels

	def _writeMissingReport(self, missingChannels):
		# Same repo content is shared by every picon size/theme variant, so this list
		# only reflects what the source actually provides - not a flaw of this one repo.
		with open(join(self.localPath, "missing_picons.txt"), "w") as f:
			for serviceName, channelName, sref in sorted(set(missingChannels)):
				f.write(f"{serviceName};{channelName};{sref}\n")

	@inlineCallbacks
	def _fetchMd5(self, url):
		result = {}
		text = yield self._fetchText(url)
		for line in text.splitlines():
			parts = line.split(None, 1)
			if len(parts) == 2:
				checksum, name = parts
				result[name.lstrip("*")] = checksum
		return result

	@inlineCallbacks
	def _fetchMap(self, url):
		result = {}
		text = yield self._fetchText(url)
		for line in text.splitlines():
			parts = line.split("=", 1)
			if len(parts) == 2:
				target, source = parts
				result[target] = source
		return result

	@inlineCallbacks
	def _fetchText(self, url):
		response = yield self._request(url)
		body = yield readBody(response)
		return body.decode("utf-8")

	def _localMd5(self, names):
		result = {}
		for name in names:
			try:
				with open(join(self.localPath, name), "rb") as f:
					result[name] = md5(f.read()).hexdigest()
			except OSError:
				pass
		return result

	@inlineCallbacks
	def _downloadPicon(self, name):
		response = yield self._request(f"{self.repoUrl}/{name}")
		finished = Deferred()
		response.deliverBody(_PiconFileSaver(finished, join(self.localPath, name)))
		yield finished

	@inlineCallbacks
	def _createSymlink(self, source, target):
		sourcePath = join(self.localPath, source)
		targetPath = join(self.localPath, target)
		if not exists(sourcePath):
			yield self._downloadPicon(source)
		if islink(targetPath) or exists(targetPath):
			remove(targetPath)
		symlink(source, targetPath)

	@inlineCallbacks
	def _request(self, url):
		response = yield self.agent.request(b"GET", url.encode("utf-8"), Headers({"user-agent": ["PiconBrowser"]}))
		if response.code != 200:
			raise ValueError(f"GET {url} failed with status {response.code}")
		return response


class PiconBrowser:
	instance = None

	def __init__(self, session):
		PiconBrowser.instance = self
		self.session = session
		self._runningSync = None
		from Scheduler import addFunctionTimer
		addFunctionTimer(SCHEDULER_TIMER_KEY, _("Picon Browser Sync"), self._schedulerRun, self._schedulerCancel, useOwnThread=True)

	def start(self):
		if not config.plugins.PiconBrowser.enabled.value:
			return
		self.download()

	def stop(self):
		self._schedulerCancel()

	def download(self):
		deferred = self._syncAll()
		deferred.addCallback(self._downloadDone).addErrback(self._downloadFailed)
		return deferred

	def _schedulerRun(self, callback, timerEntry):
		self._runningSync = self.download()
		self._runningSync.addCallbacks(lambda _: callback(True), lambda _: callback(False))

	def _schedulerCancel(self):
		if self._runningSync and not self._runningSync.called:
			self._runningSync.cancel()

	@inlineCallbacks
	def _syncAll(self):
		results = []
		paths = getActivePiconPaths()
		print(f"[{PLUGIN_NAME}] sync starting for {len(paths)} path(s)")
		if not paths:
			return results
		serviceList = BouquetParser(BOUQUET_PATH).getServiceList()
		print(f"[{PLUGIN_NAME}] {len(serviceList)} channel(s) found in bouquets")
		for index, path in enumerate(paths):
			if not exists(path):
				print(f"[{PLUGIN_NAME}] skipping path, does not exist: {path}")
				continue
			repo = getattr(config.plugins.PiconBrowser, f"sets{index}").repo.value
			print(f"[{PLUGIN_NAME}] syncing repo '{repo}' into '{path}'")
			sync = PiconSync(REPOS[repo], path, serviceList)
			result = yield sync.run()
			results.append(result)
		return results

	def _downloadDone(self, results):
		for missing, changed, notFound in results:
			print(f"[{PLUGIN_NAME}] sync done: {missing} downloaded, {changed} updated, {notFound} not found")

	def _downloadFailed(self, failure):
		print(f"[{PLUGIN_NAME}] sync failed: {failure}")

	def openSetup(self):
		self.session.openWithCallback(self._setupClosed, PiconBrowserSetup)

	def _setupClosed(self):
		pass

	def shutdown(self):
		self.stop()
		from Scheduler import functionTimers
		functionTimers.remove(SCHEDULER_TIMER_KEY)
		PiconBrowser.instance = None


def autostart(reason, session=None, **kwargs):
	if reason == 0 and session is not None:
		plugin = PiconBrowser(session)
		plugin.start()
	elif reason == 1:
		if PiconBrowser.instance:
			PiconBrowser.instance.shutdown()


def main(session, **kwargs):
	if PiconBrowser.instance:
		PiconBrowser.instance.openSetup()
	else:
		session.open(PiconBrowserSetup)


def Plugins(**kwargs):
	return [
		PluginDescriptor(
			name=PLUGIN_NAME,
			description=_("PiconBrowser description"),
			icon=resolveFilename(SCOPE_CURRENT_PLUGIN, "Extensions/PiconBrowser/plugin.png"),
			where=PluginDescriptor.WHERE_PLUGINMENU,
			fnc=main,
		),
		PluginDescriptor(
			where=PluginDescriptor.WHERE_SESSIONSTART,
			fnc=autostart,
		),
	]
